/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author akuaa
 */
public class Item {
    //Getters and Setters for name of Items
        private String name=" ";
    public String GetName (){return name;}
    public void SetName(String name){this.name=name;}
    //Getters and Setters for price of Items
    private double price=0;
   public double GetPrice(){return price;}
   public void SetPrice(double price){this.price=price;}
   
   public Item (String name, double price ){
      SetName(name);
     SetPrice (price); 
}
   
 
   
   

}
