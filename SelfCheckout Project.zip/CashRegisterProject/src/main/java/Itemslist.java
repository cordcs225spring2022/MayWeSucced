/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author akuaa
 */
public class Itemslist {
    //Gets and sets  Items columns and rows size
     private Item[][] items = new Item[3][2];
    public Item GetItem (int row,int col){return items[row][col];}
    public void SetItem(Item myItem,int row, int col){this.items[row][col]=myItem;}
   
     
   
   
    public Itemslist (Item[][] myItems){
        this.items = myItems;
   }
    
}
