
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author akuaa
 */
public class CashRegister {

    /**
     * @param args the command line arguments
     */
    //Jframe was created over here
    public static JFrame frame = new JFrame("Cash Register");
    public static ItemsScreen mainScreen = new ItemsScreen();
//    
    
    public static void paymentTransition(double total){
        //pull all your needed data out of old frame
      
        //clear out frame
        frame.removeAll();
       
        
       //add new components
       PaymentMethodScreen myPaymentScreen = new PaymentMethodScreen(null);
        myPaymentScreen.amountNeeded = total;
        
        frame.setVisible(false);
        frame = null;
        
        frame = new JFrame("Checkout");
        frame.setSize(new Dimension(1000, 500));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(myPaymentScreen);
        frame.setVisible(true);
    }
    public static void transitionBack(){
         Item[][] items = {
            {new Item("Onions",1.76), new Item("Shrimp",5.92)},
            {new Item("Water",5.36), new Item("Fish",3.99)},
            {new Item("Ribs",14.82), new Item("Banana",1.58)},
        };
        
        //allows the customer to go back to the old frame
        frame = null;
        frame = new JFrame("Cash Register");
      //size of frames 
        frame.setSize(new Dimension(1000, 500));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //New JPanel was created
        JPanel panel = new JPanel(new FlowLayout());
        panel.add(new ItemsButtons(new Itemslist(items)));        
        panel.add(mainScreen);
        
        frame.add(panel);
        
       
        
        frame.setVisible(true);
       
        
   
    }
    
  
    
    public static void main(String[] args) {
        //We created our items over here with a  2d dimensional arraylist  
        Item[][] items = {
            {new Item("Onions",1.76), new Item("Shrimp",5.92)},
            {new Item("Water",5.36), new Item("Fish",3.99)},
            {new Item("Ribs",14.82), new Item("Banana",1.58)},
        };
        //size of frames 
        frame.setSize(new Dimension(1000, 500));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //New JPanel was created
        JPanel panel = new JPanel(new FlowLayout());
        panel.add(new ItemsButtons(new Itemslist(items)));        
        panel.add(mainScreen);
        
        frame.add(panel);
        
       
        
        frame.setVisible(true);
    }
    
}
